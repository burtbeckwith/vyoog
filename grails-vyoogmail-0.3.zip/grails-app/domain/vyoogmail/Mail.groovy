package vyoogmail

class Mail {

    static constraints = {
    }
}
